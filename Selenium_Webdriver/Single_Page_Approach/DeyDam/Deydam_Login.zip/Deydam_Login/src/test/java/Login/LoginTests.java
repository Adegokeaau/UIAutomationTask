package Login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;


public class LoginTests {
        private WebDriver driver;
        @BeforeClass
        public void setup() {
                System.setProperty("webdriver.chrome.driver","C:\\Users\\Adeshola\\workspace\\Deydam_login\\Deydam_Login\\Resources\\chromedriver.exe");
                driver = new ChromeDriver();
                driver.get("https://dev.d2rxvhrryr2bkn.amplifyapp.com/login");
                driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
                driver.manage().window().maximize();
                System.out.println(driver.getTitle());
                driver.findElement(By.id("username")).sendKeys("adegokeaau");
                driver.findElement(By.id("password")).sendKeys("Blackman1*");
                driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/main/div/div[2]/div/div/div/div[2]/div/div/form/button")).click();
        }
        public static void main(String args[])throws InterruptedException{
                LoginTests tests =new LoginTests();
                tests.setup();

        }
        @AfterClass
        public void closeBrowser()throws InterruptedException {
                Thread.sleep(10000);
                driver.quit();
        }


}
